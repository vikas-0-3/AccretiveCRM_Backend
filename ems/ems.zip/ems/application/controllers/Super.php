<?php
defined('BASEPATH') OR exit('No Direct script access allowed');
class Super extends CI_Controller{

    
    public function dash() {
        $this->load->view('superadmin/superadmin_dash');
    }

    

}


?>
