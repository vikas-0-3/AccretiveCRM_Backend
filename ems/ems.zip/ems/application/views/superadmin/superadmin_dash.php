<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('dash/header');
?>
    <title>EMS SUPERADMIN</title>
    <style>
      .row .col-sm {
        background-color: teal;
        border-radius: 5px;
      }
      iframe {
        width: 100%;
        height: 90vh;
      }
</style>

<div class="container-fluid">
  <div class="row text-center m-2">
    <div class="col-sm m-2 p-2">
    <h4>Total User</h4>
    <p>0</p>
    </div>
    <div class="col-sm m-2 p-2">
    <h4>Subscription</h4>
    <p>0</p>
    </div>
    <div class="col-sm m-2 p-2">
    <h4>Trial</h4>
    <p>0</p>
    </div>
    <div class="col-sm m-2 p-2">
    <h4>Restricted</h4>
    <p>0</p>
    </div>
  </div>
</div>

<hr>


<div class="row m-2 text-center p-2">

  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Create User</h5>
        
        <a href="#" class="btn btn-primary">Go somewhere</a>
      </div>
    </div>
  </div>

  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Manage User</h5>

        <a href="#" class="btn btn-primary">Go somewhere</a>
      </div>
    </div>
  </div>

  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Manage Permission</h5>

        <a href="#" class="btn btn-primary">Go somewhere</a>
      </div>
    </div>
  </div>

  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Give Permission</h5>

        <a href="#" class="btn btn-primary">Go somewhere</a>
      </div>
    </div>
  </div>

</div>

<div class="row m-2 text-center p-2">

  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Track User</h5>
        <a href="#" class="btn btn-primary">Go somewhere</a>
      </div>
    </div>
  </div>

  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">User Logs</h5>
        <a href="#" class="btn btn-primary">Go somewhere</a>
      </div>
    </div>
  </div>

  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Manage Permission</h5>
        <a href="#" class="btn btn-primary">Go somewhere</a>
      </div>
    </div>
  </div>

  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Give Permission</h5>
        <a href="#" class="btn btn-primary">Go somewhere</a>
      </div>
    </div>
  </div>

</div>

<div class="row m-2 text-center p-2">

  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Create User</h5>
        <a href="#" class="btn btn-primary">Go somewhere</a>
      </div>
    </div>
  </div>

  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Manage User</h5>

        <a href="#" class="btn btn-primary">Go somewhere</a>
      </div>
    </div>
  </div>

  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Manage Permission</h5>

        <a href="#" class="btn btn-primary">Go somewhere</a>
      </div>
    </div>
  </div>

  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Give Permission</h5>

        <a href="#" class="btn btn-primary">Go somewhere</a>
      </div>
    </div>
  </div>

</div>
