<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<div id="container">
	<center><h1>WELCOME TO MINT EMS</h1></center>
	<br>
	<center><p>A simple EMS (Employee Management System) to manage all employee in your organization.</p></center>
	<br>
	<center>
	<div class="c_cls">
		<a href="<?php echo site_url('home/login'); ?>" class="btn btn-sm btn-info">Login</a>&emsp;
		<a href="<?php echo site_url('home/register'); ?>" class="btn btn-sm btn-info">Signup</a>
	</div>

	<center>
</div>

